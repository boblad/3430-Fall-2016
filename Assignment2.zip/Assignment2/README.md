##Assignment 2##

##first 34 carmichael numbers##
561
1105
1729
2465
2821
6601
8911
10585
15841
29341
41041
46657
52633
62745
63973
75361
101101
115921
126217
162401
172081
188461
252601
278545
294409
314821
334153
340561
399001
410041
449065
488881
512461
530881

##Step3##
Every carmichael number passes the fermat test

##Step4##
None of the carmichael numbers are prime,

##Response##
I learned that for each carmichael number, the next carmichael number takes quite
a bit longer to find than the previous carmichael number. Also, I learned that Every
carmichael number passes the fermat test but also that every carmichael number
is composite.
